# ============================================================
# Bangladesh Multi-Tool AI Agent — Google Colab Notebook
# Module 23 · Exam Week-4
# ============================================================
# Each section below is ONE Colab cell (separated by # ── CELL ──)
# Copy-paste into Colab or open the .ipynb version.
# ============================================================

# ── CELL 1: Install Dependencies ─────────────────────────────
# !pip install -q \
#     datasets \
#     pandas \
#     langchain \
#     langchain-community \
#     langchain-anthropic \
#     langchain-openai \
#     tavily-python \
#     langchainhub

# ── CELL 2: API Keys (Colab Secrets) ─────────────────────────
# from google.colab import userdata
# import os
#
# os.environ["ANTHROPIC_API_KEY"] = userdata.get("ANTHROPIC_API_KEY")
# os.environ["TAVILY_API_KEY"]    = userdata.get("TAVILY_API_KEY")
# print("✅ Keys loaded")

# ── CELL 3: Download Datasets & Build SQLite DBs ─────────────
# %run setup_databases.py

# ── CELL 4: Inspect a DB ──────────────────────────────────────
# import sqlite3, pandas as pd
#
# con = sqlite3.connect("hospitals.db")
# df  = pd.read_sql("SELECT * FROM hospitals LIMIT 5", con)
# con.close()
# df

# ── CELL 5: Build Agent ───────────────────────────────────────
# from agent import build_agent
# agent_executor = build_agent()
# print("✅ Agent ready")

# ── CELL 6: Run Queries ───────────────────────────────────────
# queries = [
#     "How many hospitals are there in Dhaka district?",
#     "List the top-rated restaurants in Chittagong.",
#     "Which universities are located in Rajshahi division?",
#     "What is the role of DGHS in Bangladesh?",
#     "What is the total number of beds in all government hospitals?",
# ]
#
# for q in queries:
#     print(f"\n{'='*60}")
#     print(f"❓ Query: {q}")
#     result = agent_executor.invoke({"input": q})
#     print(f"🤖 Answer: {result['output']}")

# ── CELL 7: Interactive Chat ──────────────────────────────────
# while True:
#     q = input("You: ")
#     if q.lower() in ("exit","quit"): break
#     r = agent_executor.invoke({"input": q})
#     print(f"Agent: {r['output']}\n")
